<?php 

	use app\Entity\Zoe;
	use app\Entity\ParcZoe;
    use app\Entity\JetSki;
    use app\Entity\FlotteJetSki;
	
	//autoload
    function chargerClasse($classe)
      {
	$classe=str_replace('\\','/',$classe);      
	require $classe . '.php'; 
      }

    spl_autoload_register('chargerClasse'); //fin Autoload
	

    //creation d'une zoe et du parc
	$zoe=new Zoe("Noir", "AAA-11-TTT");
	$parc = new ParcZoe();

    //creation des jetski
    $unJet=new JetSki("marque de jet !!!!");
    $parcJet=new FlotteJetSki();

	
 ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>TP Objet 2</title>
</head>
<body>
	<p><?=$zoe?></p>
	<p><?=$zoe->polluer()?></p>
	<p>Le parc a <?=count($parc)?> Zoe.</p>
	<p><?=Zoe::pub()?></p>
	
	<p><?=$unJet?></p>
	<p>Nombre de jet dans mon parc <?=count($parcJet)?></p>
</body>
</html>
