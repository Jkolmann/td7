<?php 

	namespace app\Interfaces;

	interface Vehicule{

		public function rouler();
		public function naviguer();
		public function voler();
	}


 ?>